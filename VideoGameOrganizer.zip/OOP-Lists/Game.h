#pragma 
#include <string>
#include <iostream>

using namespace std; 

// Preprocessing directives that prevents multiple definitions.
#ifndef Game_H
#define Game_H

class Game
{
public:

	//Default Constructor
	Game(); 

	//Constructor with Class Variables
	Game(string title, string publisher, int yearReleased);

	//Get methods or accessor functions
	string getTitle() const;
	string getPublisher() const;
	int getYearReleased() const; 

	//Set methods or mutator functions
	void setTitle(string title); 
	void setPublisher(string publisher); 
	void setYearReleased(int yearReleased); 

	//Utility member functions
	void print(); 

private:

	//Class Variables
	string title; 
	string publisher;
	int yearReleased; 
};

#endif 