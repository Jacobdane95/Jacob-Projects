#pragma once
#include "Game.h" 

struct GameNode
{
	private:
		Game Game; 
		GameNode* next; //points to next item in list 
		GameNode* previous; //points to previous item in list 

		//Access to Node class for List class is provided by friend decleration
		friend class GameList; 
};