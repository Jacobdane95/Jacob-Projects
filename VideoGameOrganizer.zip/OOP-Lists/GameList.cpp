#include "GameList.h"
#include "GameNode.h"
#include <string>
#include <sstream>
using namespace std; 

//Constructor 
GameList::GameList():head(NULL){}

//Destructor
GameList::~GameList()
{
	while (!empty())
	{
		removeFront(); 
	}
}

//Is the list empty?
bool GameList::empty() const
{
	return (head == NULL); 
}

//Get the front node
const Game& GameList::front() const
{
	return head->Game; 
}

void GameList::removeFront() const
{
	if (!empty())
	{
		GameNode* temp = head;				// temp saves the current head.
		temp->next = head; 			// Our new head is the old head's next. 
		delete temp;					// Delete the previous head.
	}
}

//Add node to the front
void GameList::addFront(const Game& e)
{
	GameNode* temp = new GameNode; //Create new node
	temp->Game = e; 
	temp->next = head;			//Current head is now next of the new node
	temp->previous = NULL; 
	if (head != NULL)
	{
		head->previous = temp; 
	}

	head = temp; //The new node is now the new head

}

void GameList::addBack(const Game& e)
{
	if (!empty())
	{ 
		GameNode* temp = new GameNode;
		tail = head;
		temp->Game = e;
		temp->next = NULL;

		//Traverse list to go to last node
		while (tail->next != NULL)
		{
			tail = tail->next;
		}

		//Add the item to the end of the list
		tail->next = temp;
		temp->previous = tail;
		tail = temp;
	}

	//If list is empty, items can't be added to the back of the list
	else
	{
		addFront(e); 
	}
	
}

//Remove node 
void GameList::removeGameObject(string target)
{
	if (!empty())
	{
		GameNode* temp = head; //Temp saves current head
		bool gameFound = false;
		while (!gameFound)
		{
			if (target == temp->Game.getTitle())
			{
				gameFound = true;

				//for node in the middle
				if ((temp->next != NULL) && (temp->previous != NULL))
				{
					temp->previous->next = temp->next;
					temp->next->previous = temp->previous;
				}

				else
				{
					if (temp->next == NULL) //this is the tail
					{
						temp->previous->next = NULL;
					}

					else //this is the head
					{
						head = temp->next;
						head->previous = NULL;
					}
				}
				delete temp; //Delete temp
				break; 
			}

			if(!gameFound)
			{
				temp = temp->next;
			}

			
		}
		if (!gameFound)
		{
			cout << "That game was not found \n";
		}
	}
	else
	{
		cout << "There are no games listed. \n";
	}
}

void GameList::displayList() const
{
	if (!empty())
	{
		cout << "The following games are listed: \n"; 
		GameNode* temp = head; 
		while (temp)	//temp evaluates to true while not null
		{
			temp->Game.print();
			//cout << temp->Game.print << endl; //Denton had cout << temp->Book << endl
			temp = temp->next; 
		}
	}

	else
	{
		cout << "There are no games listed. \n"; 
	}

}

//Searches for a title and displays
void GameList::searchByTitle(string target) const
{
	if (!empty())
	{
		GameNode* temp = head; 
		bool gameFound = false; 
		while (temp)
		{
			if (target == temp->Game.getTitle())
			{
				temp->Game.print(); 
				gameFound = true; 
			}
			temp = temp->next;
		}
		if (!gameFound)
		{
			cout << "That game was not found \n"; 
		}
	}
	else
	{
		cout << "There are no games listed \n"; 
	}
}
void GameList::editGameObject(string target) const
{
	if (!empty())
	{
		GameNode* temp = head;
		bool gameFound = false;
		while (temp)
		{
			if (target == temp->Game.getTitle())
			{
				string newTitle;
				string newPublisher; 
				int newYearReleased; 

				//Ask user input
				cout << "Enter a new title \n";
				getline(cin >> ws, newTitle);
				cout << "Enter a new publisher \n";
				getline(cin >> ws, newPublisher); 
				cout << "Enter a new release year \n";
				cin >> newYearReleased; 

				//Reset the values of the object at this point in the list
				temp->Game.setTitle(newTitle); 
				temp->Game.setPublisher(newPublisher);
				temp->Game.setYearReleased(newYearReleased); 

				gameFound = true;
			}
			temp = temp->next;
		}
		if (!gameFound)
		{
			cout << "That game was not found \n";
		}
	}
	else
	{
		cout << "There are no games listed \n";
	}
}