#include "Game.h" 

//Must use :: with class name when a method is defined outside of its class file
//Default constructor
Game::Game()
{
	setTitle(""); 
	setPublisher("");
	setYearReleased(0); 
}

//Overloaded constructor
Game::Game(string theTitle, string thePublisher, int theYearReleased)
{
	setTitle(theTitle);
	setPublisher(thePublisher);
	setYearReleased(theYearReleased); 
}

//get methods (accessor functions)
string Game::getTitle() const
{
	return title; 
}

string Game::getPublisher() const
{
	return publisher; 
}

int Game::getYearReleased() const
{
	return yearReleased; 
}

//set methods (mutator functions)
void Game::setTitle(string theTitle)
{
	title = theTitle; 
}

void Game::setPublisher(string thePublisher)
{
	publisher = thePublisher; 
}

//set flag for invalid value 
void Game::setYearReleased(int theYearReleased)
{
	if (theYearReleased < 0)
	{
		yearReleased = 0; 
	}

	else
	{
		yearReleased = theYearReleased;
	}
}

//Utility member functions
void Game::print()
{
	cout << getTitle() << " was released by " << getPublisher() << " in the year " << getYearReleased() << endl; 
}

/*ostream &operator << (ostream& out, const Game& theGame) // What is this even for?
{
	out << theGame.getTitle() << " was released by " << theGame.getPublisher() << " in the year " << theGame.getYearReleased(); 
}	// Denton had theBook.title instead, gave me errors. Are you supposed to call variable directly or use accessor? */