#pragma once
#include "GameNode.h"

class GameList
{
	public:
		GameList(); //Empty list constructor
		~GameList(); //Destructor
		bool empty() const; //Is list empty?
		const Game& front() const; //Get front element of GameList
		void removeFront() const; 
		void addFront(const Game& e); //Add to front of GameList
		void addBack(const Game& e); //Add to back of GameList
		void removeGameObject(string target); //Searches by title, then deletes it 
		void displayList() const; //Display list of games
		void searchByTitle(string target) const; //Searches for object by the title
		void editGameObject(string target) const; //Searches by title, then edits
	private:
		GameNode* head;		//Pointer to head of list
		GameNode* tail;		//Pointer to tail of list
};