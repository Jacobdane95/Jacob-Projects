// OOP-Lists.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <sstream>
#include <string>
#include <conio.h>
#include "Game.h"
#include "GameList.h"

using namespace std; 

// Press any key to continue.
void pressAnyKey()
{
	cout << "Press any key to continue" << endl << endl;
	_getch();					// Waits and gets next character entered.		
}

int main()
{
	GameList gameList; 
	//Initial 5 items in list 
	Game a = Game("Metal Gear Solid", "Konami", 1998); 
	Game b = Game("Bloodborne", "FromSoftware", 2015);
	Game c = Game("Resident Evil", "Capcom", 1996);
	Game d = Game("Super Mario Bros", "Nintendo", 1985);
	Game e = Game("The Last of Us", "Naughty Dog", 2013); 

	gameList.addFront(a);
	gameList.addFront(b);
	gameList.addFront(c);
	gameList.addFront(d);
	gameList.addFront(e);

	//Display menu for user choice
	int choice; 
	//int input; 
	bool keepGoing = true; 
	while (keepGoing)
	{
		cout << endl
			<< "---------------------------------------------------------------------\n"
			<< " Select an option from the menu below\n"
			<< " by entering the number of the choice\n"
			<< "---------------------------------------------------------------------\n"
			<< "Option 1: Add a game to the front of the list \n"
			<< "Option 2: Add a game to the back of the list \n"
			<< "Option 3: Search and display a specific item in the list \n"
			<< "Option 4: Edit the contents of a specific item in the list \n"
			<< "Option 5: Remove a certain item from the list \n"
			<< "Option 6: Display the entire list \n"
			<< "Option 7: End the program \n"
			<< "---------------------------------------------------------------------\n\n"
			<< "Enter your choice : \n\n";
		cin >> choice; 
		//Another way I tried to filter out char inputs, but didn't work
		/*cin >> input; 
		while (input != 1, 2, 3, 4, 5, 6, 7)
		{
			input = 0; 
			cout << "That was not an available option. Try again \n";
			cin >> input; 
		}
		choice = input; */
		switch (choice)
		{
			case 1: // Add to front of the list
			{
				//need to add data an instance of class and add in data values
				string title; 
				string publisher;
				int yearReleased; 
				cout << "Enter the game's title \n";
				getline(cin >> ws, title); //ws allows spaces in the title, must include <sstream>
				cout << "Enter the game's publisher \n"; 
				getline(cin >> ws, publisher); 
				cout << "Enter the year that the game was released \n";
				cin >> yearReleased;
				while (cin.fail()) //to check if user inputs char for int year
				{
					cout << "The year released must be a number. Try again \n";
					cin.clear();
					cin.ignore(numeric_limits<streamsize>::max(), '\n');
					cin >> yearReleased;
				}
				Game e = Game(title, publisher, yearReleased); 
				gameList.addFront(e); 

				pressAnyKey(); 
				break; 
			}

			case 2: // Add to back of the list
			{
				//need to add data an instance of class and add in data values
				string title;
				string publisher;
				int yearReleased;
				cout << "Enter the game's title \n";
				getline(cin >> ws, title); //ws allows spaces in the title, must include <sstream>
				cout << "Enter the game's publisher \n";
				getline(cin >> ws, publisher);
				cout << "Enter the year that the game was released \n";
				cin >> yearReleased;
				while (cin.fail())
				{
					cout << "The year released must be a number. Try again \n"; 
					cin.clear();
					cin.ignore(numeric_limits<streamsize>::max(), '\n');
					cin >> yearReleased; 
				}

				Game e = Game(title, publisher, yearReleased);
				gameList.addBack(e);

				pressAnyKey();
				break; 
			}

			case 3: // Search for a specific item in the list and display contents
			{
				string title; 
				cout << "Enter a game's title \n";
				getline(cin >> ws, title);
				gameList.searchByTitle(title); 
				pressAnyKey(); 
				break; 
			}

			case 4: // Edit an item in the list
			{
				string title; 
				cout << "What game do you want to edit? \n";
				getline(cin >> ws, title);
				gameList.editGameObject(title); 
				pressAnyKey(); 
				break; 
			}

			case 5: // Remove an item in the list
			{
				string title; 
				cout << "What game do you want to remove from the list? \n";
				getline(cin >> ws, title);
				gameList.removeGameObject(title); 
				pressAnyKey();
				break; 
			}

			case 6: // Display the entire list
			{
				gameList.displayList(); 
				pressAnyKey();
				break; 
			}

			case 7: // End the program
			{
				keepGoing = false; // Will exit the loop and end program
				cout << "The program is now ending \n";
				pressAnyKey();
				break; 
			}

			default: // Catch for invalid input 
			{
				cout << "That was not an available option. Try again \n"; 
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');

				pressAnyKey();
				break; 
			}
		}
	}
	// End the program
	return 0; 
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
