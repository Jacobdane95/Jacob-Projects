// Project1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <random>
#include <vector> 
#include <conio.h>

using namespace std; 

struct process
{
	bool active; 
	int processID; 
	int arrivalTime; 
	int totalCPUTime; 
	int remainingCPUTime; 
	int turnaroundTime; 
};

vector<process> PROCESS_VECTOR; // once initialized, this vector becomes static so it may initialize the dynamic array
						//to the same initial values before each scheduling algorithm 
vector<process> pVector; //vector that houses all processes
int length; //size of pVector
int time; //overall time of execution 
int maxArrivalTime; //used for uniform distribution calculation
int average; //used for normal distribution calculation
int standardDeviation;	//used for normal distribution calculation
double avgTT; //for calculating the average turnaround time at the end of each process

void initializeProcesses(vector<process> &PROCESS_VECTOR, vector<process> &pVector); 
void reinitializeVector(vector<process> &PROCESS_VECTOR, vector<process> &pVector);
void firstComeFirstServed(vector<process> &pVector);
void shortestJobFirst(vector<process> &pVector);
void shortestRemainingTime(vector<process> &pVector);
void CPU(vector<process> &pVector, int index);
bool unfinishedProcesses(vector<process> &pVector);
int findMinArrivalTime(vector<process> &pVector);
int findMinRemainingTime(vector<process> &pVector);
void calculateTT(vector<process> &pVector, int index);
double calculateAVGTT(vector<process> &pVector);

void pressAnyKey()
{
	cout << "Press any key to continue" << endl << endl;
	_getch();					// Waits and gets next character entered.		
}

int main()
{
	
	cout << "Enter the amount of processes in the simulation:\n"; 
	cin >> length; 
	cout << "Enter a value for the latest time a process should enter the simulation:\n";
	cin >> maxArrivalTime; 
	cout << "Enter a value for to simulate average process run-time: \n"; 
	cin >> average; 
	cout << "Enter a value to simulate the standard deviation of process run-time: \n"; 
	cin >> standardDeviation; 

	initializeProcesses(PROCESS_VECTOR, pVector);

	bool keepGoing = true; 
	int choice; 

	while (keepGoing)
	{
		cout << endl
			<< "Option 1: First-Come-First-Serve \n"
			<< "Option 2: Shortest-Job-First \n"
			<< "Option 3: Shortest-Remaining-Time \n"
			<< "Option 4: Run All Consecutively \n"
			<< "Option 5: End Program \n"; 

		cin >> choice; 
		switch (choice)
		{
			case 1:
			{
				firstComeFirstServed(pVector);
				reinitializeVector(PROCESS_VECTOR, pVector);
				time = 0;

				pressAnyKey();
				break; 
			}

			case 2:
			{
				shortestJobFirst(pVector);
				reinitializeVector(PROCESS_VECTOR, pVector);
				time = 0;

				pressAnyKey();
				break; 
			}

			case 3:
			{
				shortestRemainingTime(pVector);
				reinitializeVector(PROCESS_VECTOR, pVector);
				time = 0;

				pressAnyKey();
				break; 
			}

			case 4:
			{
				firstComeFirstServed(pVector);
				reinitializeVector(PROCESS_VECTOR, pVector);
				time = 0;
				shortestJobFirst(pVector);
				reinitializeVector(PROCESS_VECTOR, pVector);
				time = 0;
				shortestRemainingTime(pVector);
				reinitializeVector(PROCESS_VECTOR, pVector);
				time = 0;

				pressAnyKey();
				break; 
			}

			case 5:
			{
				keepGoing = false; // Will exit the loop and end program
				cout << "The program is now ending \n";
				pressAnyKey();
				break;
			}

			default: // Catch for invalid input 
			{
				cout << "That was not an available option. Try again \n";
				cin.clear();
				cin.ignore(numeric_limits<streamsize>::max(), '\n');

				pressAnyKey();
				break;
			}
		}
	}

	return 0;
}

//this initializes values to each process in vector that will be reused after each scheduling algorithm
void initializeProcesses(vector<process> &PROCESS_VECTOR, vector<process> &pVector)
{
	default_random_engine generator;
	normal_distribution<double> nDistribution(average, standardDeviation);
	uniform_int_distribution<int> uDistribution(0, maxArrivalTime);

	for (int i = 0; i < length; i++)
	{
		double dCPUtime = nDistribution(generator); 
		int iCPUtime = abs(round(dCPUtime));
		if (iCPUtime <= 0) iCPUtime = 1; // so no process can require 0 CPU time
		struct process p = { true, //active
							i + 1, //processID
							uDistribution(generator), //arrivalTime
							iCPUtime, //totalCPUTime
							iCPUtime, //remainingCPUTime
							0 }; //turnaroundTime

		PROCESS_VECTOR.push_back(p); 
		pVector.push_back(p); 
		

		cout << "Process " << PROCESS_VECTOR[i].processID << " will arrive at time " << PROCESS_VECTOR[i].arrivalTime 
			<< " and will require " << PROCESS_VECTOR[i].totalCPUTime << " CPU cylces to be completed." << endl; 
	}

}

//uses static vector to reinitialize the original values to the dynamic vector
void reinitializeVector(vector<process> &PROCESS_VECTOR, vector<process> &pVector)
{
	for (int i = 0; i < length; i++)
	{
		pVector[i].active = true;
		pVector[i].processID = PROCESS_VECTOR[i].processID;
		pVector[i].arrivalTime = PROCESS_VECTOR[i].arrivalTime;
		pVector[i].totalCPUTime = PROCESS_VECTOR[i].totalCPUTime;
		pVector[i].remainingCPUTime = PROCESS_VECTOR[i].remainingCPUTime;
		pVector[i].turnaroundTime = PROCESS_VECTOR[i].turnaroundTime;
	}
}

void firstComeFirstServed(vector<process> &pVector)
{
	int index; 
	
	while (unfinishedProcesses(pVector))
	{
		index = findMinArrivalTime(pVector); 
		if (index == length)
		{
			time++;
		}
		else
		{
			while (pVector[index].remainingCPUTime > 0)
			{
				CPU(pVector, index); 
			}
		}
	}

	avgTT = calculateAVGTT(pVector); 
	cout << "The average amount of turnaround time for First-Come-First-Served is: " << avgTT << " time units. \n"; 
} 

void shortestJobFirst(vector<process> &pVector)
{
	int index; 
	//first process of SJF is the same as FCFS
	do
	{
		index = findMinArrivalTime(pVector);
 		if (index == length)
		{
			time++;
		}

	} while (index == length); 

	while (pVector[index].active)
	{
		if (index == length)
		{
			time++;
		}
		else
		{
			while (pVector[index].remainingCPUTime > 0)
			{
				CPU(pVector, index);
			}
		}
	} 

	//The actual algorithm for SJF
	while (unfinishedProcesses(pVector))
	{
		index = findMinRemainingTime(pVector); 
		if (index == length)
		{
			time++; 
		}
		else
		{
			while (pVector[index].remainingCPUTime > 0)
			{
				CPU(pVector, index);
			}
		}
	}

	avgTT = calculateAVGTT(pVector); 
	cout << "The average amount of turnaround time for Shortest-Job-First is: " << avgTT << " time units. \n";
}

void shortestRemainingTime(vector<process> &pVector)
{
	int index;

	//first process of SRT is the same as FCFS
	do
	{
		index = findMinArrivalTime(pVector);
		if (index == length)
		{
			time++;
		}

	} while (index == length);
	CPU(pVector, index);

	//Actual Algorithm of SRT
	while (unfinishedProcesses(pVector))
	{
		index = findMinRemainingTime(pVector);
		if (index == length)
		{
			time++;
		}
		else
		{
			CPU(pVector, index);
		}
	}

	avgTT = calculateAVGTT(pVector); 
	cout << "The average amount of turnaround time for Shortest-Remaining-Time is: " << avgTT << " time units. \n";
}

void CPU(vector<process> &pVector, int index)
{
	pVector[index].remainingCPUTime--; 
	time++; 
	if (pVector[index].remainingCPUTime == 0)
	{
		pVector[index].active = false; 
		calculateTT(pVector, index); 
	}
}

bool unfinishedProcesses(vector<process> &pVector) //loops through array until it finds a process that is active and returns true, 
{											//returns false if no process is active
	for (int i = 0; i < length ; i++)
	{
		if (pVector[i].active)
		{
			return true; 
		}
	}

	return false; 
}

int findMinArrivalTime(vector<process> &pVector) //returns the index which contains the process that arrived first
{
	int minIndex = length; //if no process is ready, a value outside of index values is returned to let overall time increase
	int temp = INT_MAX; 
	
	for (int i = 0; i < length; i++)
	{
		//check to make sure the process has a earliest arrival time, it is active, and it is time for it to start 
		if (temp >= pVector[i].arrivalTime && pVector[i].active && pVector[i].arrivalTime <= time)
		{
			temp = pVector[i].arrivalTime;
			minIndex = i;
		}
	}

	return minIndex; 
}

int findMinRemainingTime(vector<process> &pVector) //returns the index which contains the process with the least amount of time
{
	int minIndex = length; //if no process is ready, a value outside of index values is returned to let overall time increase
	int temp = INT_MAX; 

	for (int i = 0; i < length; i++)
	{
		//check to make sure the process has a lesser remaining time, it is active, and it is time for it to start 
		if (temp > pVector[i].remainingCPUTime && pVector[i].active && pVector[i].arrivalTime <= time)
		{
			temp = pVector[i].remainingCPUTime; 
			minIndex = i; 
		}
	}
	return minIndex; 
}

void calculateTT(vector<process> &pVector, int index)
{
	pVector[index].turnaroundTime = time - pVector[index].arrivalTime; 
}

double calculateAVGTT(vector<process> &pVector)
{
	int iTT; //turnaround time is stored in array as int
	double dTT; //used to typecast the TT into a double

	for (int i = 0; i < length; i++)
	{
		iTT = pVector[i].turnaroundTime; 
		dTT = (double)iTT;
		avgTT = avgTT + dTT; 
	}
	avgTT = avgTT / length;
	return avgTT; 
} 


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
