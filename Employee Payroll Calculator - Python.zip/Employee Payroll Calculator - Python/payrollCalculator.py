def payCalculator(wage):
    try:
        sHours = input ("Enter the amount of hours worked: ")
        hours = float(sHours)
    except ValueError:
        varName = "Hours "
        hours = errorCheck(varName)

    overtimeHours = 0
    if (hours > 40):
        overtimeHours = hours - 40
        hours = 40
    weeklyPay = (hours * wage) + (overtimeHours * (wage * 1.5))
    weeklyPay = round(weeklyPay, 2) 
    print("The gross pay for the week is: " + str(weeklyPay) + "\n")

def errorCheck(varName):
    sInput = input(varName + "must be a number: ")
    try:
        numInput = float(sInput)
    except ValueError:
        numInput = errorCheck(varName)
    return numInput

def addEmployee():
    name = input("Enter the employee's name: " )
    idNumber = input("Assign the employee an ID number: ")
    try:
        sWage = input("Enter the employee's starting wage: ")
        wage = float(sWage)
    except ValueError:
        varName = "Wage "
        wage = errorCheck(varName)

    newEmployee = Employee(name, idNumber, wage)
    return newEmployee

def searchEmployee(employeeList):
    employeeFound = False
    idNum = input("Enter the ID number of the employee you are searching for: ")
    i = 0
    for x in employeeList:
        if(idNum == employeeList[i].idNumber):
            employeeFound = True
            break
        i+=1
    if(employeeFound == False):
        i = -2
        
    return i

class Employee:
    def __init__(self, name, idNumber, payRate):
        self.name = name
        self.idNumber = idNumber
        self.payRate = payRate

    def displayInfo(self):
        print("Employee #: " + self.idNumber + "\nName: " + str(self.name) + "\nHourlyWage: " + str(self.payRate) + "\n")


#main
keepGoing = True
employeeList = []
employee1 = Employee("Jacob Johnson", "496422", 10.5)
employeeList.append(employee1)

while keepGoing:
    sOption = input("1: Add new employee \n" +
                    "2: Delete employee \n" +
                    "3: Edit employee wage \n" +
                    "4: Calculate gross pay \n" +
                    "5: Display employee information \n" +
                    "6: End Program \n")
    try:   
        option = int(sOption)
    except:
        varName = "The input "
        option = errorCheck(varName)
    
    if (option == 1):
        employee = addEmployee()
        employeeList.append(employee)

    elif(option == 2):
        i = searchEmployee(employeeList)
        if(i == -2):
            print("That number did not match any of the employees' ID. \n" )

        else:
            print("Employee #: " + employeeList[i].idNumber + " has been removed. \n")
            del employeeList[i]
        
    elif(option == 3):
        i = searchEmployee(employeeList)
        if(i == -2):
            print("That number did not match any of the employees' ID. \n" )

        else:
            try:
                sWage = input("Enter the employee's new wage: ")
                wage = float(sWage)
            except ValueError:
                varName = "Wage "
                errorCheck(varName)

        employeeList[i].payRate = wage
        
        
    elif(option == 4):
        i = searchEmployee(employeeList)
        if(i == -2):
            print("That number did not match any of the employees. \n" )

        else:
            payCalculator(employeeList[i].payRate)

    elif(option == 5):
        i = searchEmployee(employeeList)
        if(i == -2):
            print("That number did not match any of the employees. \n" )

        else:
            employeeList[i].displayInfo(); 

    elif(option == 6):
        keepGoing = False

    else:
        print("That was not a valid option.")
    












    

