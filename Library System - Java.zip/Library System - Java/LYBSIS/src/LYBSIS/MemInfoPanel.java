package LYBSIS;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;

import java.awt.Color;
import java.awt.GridBagConstraints;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;

import javax.swing.JButton;

public class MemInfoPanel extends JPanel{
	public JTextField nameField;
	public  JTextField memIDField;
	public JTextField emailField;
	public JTextField addressField;
	public int memIndex = -1; 
	public MemInfoPanel() {
		setBackground(new Color(128, 222, 234));
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel nameLbl = new JLabel("Member Name:");
		nameLbl.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbc_nameLbl = new GridBagConstraints();
		gbc_nameLbl.insets = new Insets(0, 0, 5, 0);
		gbc_nameLbl.gridx = 0;
		gbc_nameLbl.gridy = 0;
		add(nameLbl, gbc_nameLbl);
		
		nameField = new JTextField();
		GridBagConstraints gbc_nameField = new GridBagConstraints();
		gbc_nameField.insets = new Insets(0, 0, 5, 0);
		gbc_nameField.fill = GridBagConstraints.HORIZONTAL;
		gbc_nameField.gridx = 0;
		gbc_nameField.gridy = 1;
		add(nameField, gbc_nameField);
		nameField.setColumns(10);
		
		JLabel memIDLbl = new JLabel("Member ID:");
		GridBagConstraints gbc_memIDLbl = new GridBagConstraints();
		gbc_memIDLbl.insets = new Insets(0, 0, 5, 0);
		gbc_memIDLbl.gridx = 0;
		gbc_memIDLbl.gridy = 2;
		add(memIDLbl, gbc_memIDLbl);
		
		memIDField = new JTextField();
		GridBagConstraints gbc_memIDField = new GridBagConstraints();
		gbc_memIDField.insets = new Insets(0, 0, 5, 0);
		gbc_memIDField.fill = GridBagConstraints.HORIZONTAL;
		gbc_memIDField.gridx = 0;
		gbc_memIDField.gridy = 3;
		add(memIDField, gbc_memIDField);
		memIDField.setColumns(10);
		
		JLabel emailLbl = new JLabel("Member Email:");
		GridBagConstraints gbc_emailLbl = new GridBagConstraints();
		gbc_emailLbl.insets = new Insets(0, 0, 5, 0);
		gbc_emailLbl.gridx = 0;
		gbc_emailLbl.gridy = 4;
		add(emailLbl, gbc_emailLbl);
		
		emailField = new JTextField();
		GridBagConstraints gbcEmailField = new GridBagConstraints();
		gbcEmailField.insets = new Insets(0, 0, 5, 0);
		gbcEmailField.fill = GridBagConstraints.HORIZONTAL;
		gbcEmailField.gridx = 0;
		gbcEmailField.gridy = 5;
		add(emailField, gbcEmailField);
		emailField.setColumns(10);
		
		JLabel addressLbl = new JLabel("Member Address: ");
		GridBagConstraints gbc_addressLbl = new GridBagConstraints();
		gbc_addressLbl.insets = new Insets(0, 0, 5, 0);
		gbc_addressLbl.gridx = 0;
		gbc_addressLbl.gridy = 6;
		add(addressLbl, gbc_addressLbl);
		
		addressField = new JTextField();
		GridBagConstraints gbc_addressField = new GridBagConstraints();
		gbc_addressField.insets = new Insets(0, 0, 5, 0);
		gbc_addressField.fill = GridBagConstraints.HORIZONTAL;
		gbc_addressField.gridx = 0;
		gbc_addressField.gridy = 7;
		add(addressField, gbc_addressField);
		addressField.setColumns(10);
		
		JButton submitBtn = new JButton("Submit");
		GridBagConstraints gbc_submitBtn = new GridBagConstraints();
		gbc_submitBtn.insets = new Insets(0, 0, 5, 0);
		gbc_submitBtn.gridx = 0;
		gbc_submitBtn.gridy = 8;
		add(submitBtn, gbc_submitBtn);
		submitBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String name = nameField.getText(); 
				String memID = memIDField.getText();
				String email = emailField.getText(); 
				String address = addressField.getText(); 
				Calendar expirationDate = Calendar.getInstance(); 
				expirationDate.add(Calendar.YEAR, 3);
				if(memIndex == -1) {
					Member m1 = new Member(memID, name, email, address, expirationDate); 
					LYBSIS.members.add(m1); 
				}
				
				else {
					LYBSIS.members.get(memIndex).setName(nameField.getText());
					LYBSIS.members.get(memIndex).setEmail(emailField.getText());
					LYBSIS.members.get(memIndex).setAddress(addressField.getText());
					memIDField.setEditable(true);
					LYBSIS.mainFrame.memInfoPanel.setVisible(false);
					LYBSIS.mainFrame.scroll.setVisible(true); 
				}
				
				nameField.setText("");
				memIDField.setText("");
				emailField.setText("");
				addressField.setText("");
				memIndex = -1; 
				
			}
		}); 
		
		JButton backBtn = new JButton("Go Back");
		GridBagConstraints gbc_backBtn = new GridBagConstraints();
		gbc_backBtn.gridx = 0;
		gbc_backBtn.gridy = 9;
		add(backBtn, gbc_backBtn);
		backBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				LYBSIS.mainFrame.memInfoPanel.setVisible(false);
				LYBSIS.mainFrame.scroll.setVisible(true); 
				
				nameField.setText("");
				memIDField.setText("");
				emailField.setText("");
				addressField.setText("");
			}
		});
	}
}
