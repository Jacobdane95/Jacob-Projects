package LYBSIS;

import java.util.Calendar;
import java.util.List;

import javax.swing.JOptionPane;

public class Librarian {
	private String name = ""; 
	private String userID = "";
	private String password = ""; 
	
	//constructor
	public Librarian(String name, String userID, String password) {
		this.name = name; 
		this.userID = userID; 
		this.password = password; 
	}
	
	//get methods
	public String getName() {
		return name; 
	}
	public String getUserID() { 
		return userID; 
	}
	
	public String getPassword() {
		return password; 
	}
	
	//set methods
	public void setName(String theName) {
		name = theName; 
	}
	public void setUserID(String theUserID) {
		userID = theUserID; 
	}
	
	public void setPassword(String thePassword) {
		password = thePassword; 
	}
	
	//functionality methods
	public void lendBook(int bookIndex, int memIndex) {
		int quantity = LYBSIS.catalog.get(bookIndex).getQuantity();
		
		if(LYBSIS.members.get(memIndex).getFines() > 0.0) {
			JOptionPane.showMessageDialog(null, "Member must pay fines before borrowing a book");
		}
		else if(quantity == 0) {
			JOptionPane.showMessageDialog(null, "There are no copies of '" + LYBSIS.catalog.get(bookIndex).getTitle() +
					"' available to be borrowed right now. "); 
		}
		else if(!LYBSIS.catalog.get(bookIndex).getBorrowable()) {
			JOptionPane.showMessageDialog(null, "That book can only be read in the library. ");
		}
		else if(LYBSIS.catalog.get(bookIndex).getReserved() && LYBSIS.catalog.get(bookIndex).getQuantity()== 1) {
			JOptionPane.showMessageDialog(null, "That book is currently being reserved. ");
		}
		
		else if(LYBSIS.members.get(memIndex).getExpirationDate().before(Calendar.getInstance())) {
			JOptionPane.showMessageDialog(null, "The member must renew his or her membership. "); 
		}
		
		else if(LYBSIS.members.get(memIndex).hasOverDueBook()) {
			JOptionPane.showMessageDialog(null, "The member has an overdue book in his or her possession. "); 
		}
		else {
			quantity--; 
			Calendar returnDate = Calendar.getInstance(); 
			returnDate.add(Calendar.DAY_OF_YEAR, LYBSIS.borrowBookDuration);
			LYBSIS.catalog.get(bookIndex).setQuantity(quantity);
			LYBSIS.members.get(memIndex).addToBooksBorrowed(LYBSIS.catalog.get(bookIndex), returnDate);
			LYBSIS.appendOutputForTextArea(LYBSIS.catalog); 
		}
	}
	
	public void returnBook(int memIndex) {
		String input = JOptionPane.showInputDialog(null, "Enter the ISBN of the book being returned. "); 
		int bookMemIndex = LYBSIS.members.get(memIndex).searchMemBooks(input); 
		if (bookMemIndex == -1) {
			//error message handled by search function
		}
		else {
			LYBSIS.members.get(memIndex).removeFromBooksBorrowed(bookMemIndex);
			int catalogIndex = LYBSIS.searchBook(input);
			int quantity = LYBSIS.catalog.get(catalogIndex).getQuantity(); 
			quantity++; 
			LYBSIS.catalog.get(catalogIndex).setQuantity(quantity);
			LYBSIS.appendOutputForTextArea(LYBSIS.catalog);
			if(LYBSIS.catalog.get(catalogIndex).getReserved()) {
				Calendar holdDate = Calendar.getInstance(); 
				holdDate.add(Calendar.DAY_OF_YEAR, 14);
				LYBSIS.reservedBooks.add(0, LYBSIS.catalog.get(catalogIndex)); 
				LYBSIS.reservedBooks.get(0).setReservedDate(holdDate); 
				memIndex = LYBSIS.searchMember(LYBSIS.reservedBooks.get(0).getReservedBy()); 
				JOptionPane.showMessageDialog(null, "An email has been sent to " + LYBSIS.members.get(memIndex).getEmail()); 
			}
		}
	}
	
	public void renewLoan(int memIndex) {
		String input = JOptionPane.showInputDialog(null, "Enter the ISBN of the book being renewed. "); 
		int bookMemIndex = LYBSIS.members.get(memIndex).searchMemBooks(input);
		List<Book> booksBorrowedCopy = LYBSIS.members.get(memIndex).getBooksBorrowed(); 
		if (bookMemIndex == -1) {
			//error message handled by search function
		}
		else if(LYBSIS.members.get(memIndex).getFines() > 0.0) {
			JOptionPane.showMessageDialog(null, "Member must pay fines before borrowing a book");
		}
		else if(booksBorrowedCopy.get(bookMemIndex).getRenewed()) {
			JOptionPane.showMessageDialog(null, "That book cannot be renewed again. "); 
		}
		else if(LYBSIS.members.get(memIndex).hasOverDueBook()) {
			JOptionPane.showMessageDialog(null, "The member has an overdue book in his or her possession. "); 
		}
		else {
			booksBorrowedCopy.get(bookMemIndex).setRenewed(true);
			Calendar returnDate = booksBorrowedCopy.get(bookMemIndex).getReturnDate();
			returnDate.add(Calendar.DAY_OF_YEAR, LYBSIS.borrowBookDuration);
			booksBorrowedCopy.get(bookMemIndex).setReturnDate(returnDate);
			LYBSIS.members.get(memIndex).setBooksBorrowed(booksBorrowedCopy);
			JOptionPane.showMessageDialog(null, "Member # " + LYBSIS.members.get(memIndex).getMemberID() + " has renewed their copy of '"
							+ booksBorrowedCopy.get(bookMemIndex).getTitle() + ".' The time they can borrow it has increased by three weeks.");
		}
	}
	
	public void payFines(int memIndex) {
		String input = JOptionPane.showInputDialog(null, "Enter the amount of money being payed. "); 
		try {
			double payment = Double.parseDouble(input);
			double fines = LYBSIS.members.get(memIndex).getFines();
			fines = fines - payment; 
			if (fines < 0.0) {
				JOptionPane.showMessageDialog(null, "You owe the member $" + Math.abs(fines));
				fines = 0.0; 
			}
			
			LYBSIS.members.get(memIndex).setFines(fines);
			JOptionPane.showMessageDialog(null, LYBSIS.members.get(memIndex).getName() + " owes " + LYBSIS.members.get(memIndex).getFines()); 
		}
		
		catch (Exception e) {
			JOptionPane.showMessageDialog(null, "An Error has occured. You will need to retry your previous action", "Failure",  JOptionPane.ERROR_MESSAGE);
		}
		 
	}
	
	public Calendar renewMemberShip(double fines, Calendar expirationDate, int memIndex) {
		Calendar minRenewalDate = Calendar.getInstance(); 
		minRenewalDate.add(Calendar.MONTH, 6); 
		if (fines > 0.0){
			JOptionPane.showMessageDialog(null, "Member must pay fines before renewing their membership"); 
		}
		else if(LYBSIS.members.get(memIndex).hasOverDueBook()) {
			JOptionPane.showMessageDialog(null, "The member has an overdue book in his or her possession. "); 
		}
		else if(expirationDate.after(minRenewalDate)) {
			JOptionPane.showMessageDialog(null, "It is too early for the member to renew his or her membership. ");
		}
		else {
		expirationDate = Calendar.getInstance(); 
		expirationDate.add(Calendar.YEAR, 3);
		}
		
		return expirationDate; 
	}
	
	public void reserveBook(int bookIndex, int memIndex) {
		if (LYBSIS.members.get(memIndex).getFines() > 0.0){
			JOptionPane.showMessageDialog(null, "Member must pay fines before renewing their membership"); 
		}
		else if(LYBSIS.members.get(memIndex).hasOverDueBook()) {
			JOptionPane.showMessageDialog(null, "The member has an overdue book in his or her possession. "); 
		}
		else {
			
		LYBSIS.catalog.get(bookIndex).setReserved(true);
		LYBSIS.catalog.get(bookIndex).setReservedBy(LYBSIS.members.get(memIndex).getMemberID());
		JOptionPane.showMessageDialog(null, "Member # " + LYBSIS.members.get(memIndex).getMemberID() + " has reserved a copy of '"
										+ LYBSIS.catalog.get(bookIndex).getTitle() + ".'"); 
		}
	}
	
}










