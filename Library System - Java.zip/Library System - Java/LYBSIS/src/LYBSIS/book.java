package LYBSIS;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Comparator;


public class Book implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String title;
	private String author; 
	private String isbn; 
	private int quantity;
	private boolean borrowable; 
	private boolean reserved; 
	private Calendar returnDate; 
	private Calendar reservedDate;
	private String reservedBy; 
	private boolean renewed; 
	
	//constructor
	public Book(String title, String author, String isbn, int quantity, boolean borrowable)
	{
		this.title = title; 
		this.author = author;
		this.isbn = isbn; 
		this.quantity = quantity; 
		this.borrowable = borrowable;
		this.reserved = false; 
		this.returnDate = null; 
		this.reservedDate = null; 
		this.reservedBy = null; 
		this.renewed = false; 
	}
	
	//get methods
	public String getTitle()
	{
		return title; 
	}
	
	public String getAuthor()
	{
		return author; 
	}
	
	public String getIsbn()
	{
		return isbn; 
	}
	
	public int getQuantity() {
		return quantity; 
	}
	
	public boolean getBorrowable() {
		return borrowable; 
	}
	
	public boolean getReserved() {
		return reserved; 
	}
	
	public Calendar getReturnDate() {
		return returnDate; 
	}
	
	public Calendar getReservedDate() {
		return reservedDate; 
	}
	
	public String getReservedBy() {
		return reservedBy; 
	}
	
	public boolean getRenewed() {
		return renewed; 
	}
	//set methods
	public void setTitle(String theTitle)
	{
		title = theTitle; 
	}
	
	public void setAuthor(String theAuthor)
	{
		author = theAuthor; 
	}
	
	public void setIsbn(String theIsbn)
	{
		isbn = theIsbn;
	}
	
	public void setQuantity(int theQuantity) {
		quantity = theQuantity; 
	}
	
	public void setBorrowable(boolean borrowableStatus) {
		borrowable = borrowableStatus; 
	}
	
	public void setReserved(boolean reservation) {
		reserved = reservation; 
	}
	
	public void setReturnDate(Calendar theReturnDate) {
		returnDate = theReturnDate; 
	}
	
	public void setReservedDate(Calendar theDate) {
		reservedDate = theDate; 
	}
	
	public void setReservedBy(String memID) {
		reservedBy = memID; 
	}
	
	public void setRenewed(boolean isRenewed) {
		renewed = isRenewed; 
	}
	
	//Comparator for the list by the book title
	public static Comparator<Book> BookNameComparator = new Comparator<Book>() {

		public int compare(Book b1, Book b2) {
		   String BookName1 = b1.getTitle().toUpperCase();
		   String BookName2 = b2.getTitle().toUpperCase();

		   //ascending order
		   return BookName1.compareTo(BookName2);
		}
	};
	
	//Comparator for the list by the book Author
		public static Comparator<Book> BookAuthorComparator = new Comparator<Book>() {

			public int compare(Book b1, Book b2) {
			   String BookAuthor1 = b1.getAuthor().toUpperCase();
			   String BookAuthor2 = b2.getAuthor().toUpperCase();

			   //ascending order
			   return BookAuthor1.compareTo(BookAuthor2);
			}
		};
		
		//Comparator for the list by the book Author
		public static Comparator<Book> BookIsbnComparator = new Comparator<Book>() {

			public int compare(Book b1, Book b2) {
				String BookIsbn1 = b1.getIsbn();
				String BookIsbn2 = b2.getIsbn();

				//ascending order
				return BookIsbn1.compareTo(BookIsbn2);
			}
		};
	
	public String displayInfo() {
		String output; 
		output = "Title: " + title + "       " +
					"Author: " + author + "       " +
					"ISBN: " + isbn + "\n"; 
		//JOptionPane.showMessageDialog(null, output); 
		return output; 
	}
	
}