package LYBSIS;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JTextArea;
import java.awt.BorderLayout;
import java.awt.Button;


public class MainFrame extends JFrame{
	
	JButton loginBtn = new JButton("Login");
	JButton searchBtn = new JButton("Search"); 
	JButton lendBookBtn = new JButton("Lend Book");
	JButton receiveBookBtn = new JButton("Receive Book"); 
	JTextArea displayArea = new JTextArea();
	LoginPanel loginPanel = new LoginPanel(); 
	MemInfoPanel memInfoPanel = new MemInfoPanel();
	AddBookPanel addBookPanel = new AddBookPanel(); 
	JScrollPane scroll = new JScrollPane(displayArea); 
	JPanel eastPanel = new JPanel(); 
	
	public MainFrame() { 
		Icon animation = new ImageIcon("D:/Java Apps/LYBSIS/LYBSISgraphic.gif"); 
		JLabel iconLabel = new JLabel(animation); 
		getContentPane().setLayout(new BorderLayout(0, 0));
		setExtendedState(JFrame.MAXIMIZED_BOTH);
		pack(); 
		setTitle("LYBSIS"); 
		getContentPane().getPreferredSize(); 
		
		getContentPane().add(loginPanel, BorderLayout.NORTH);
		
		displayArea.setTabSize(20); 
		displayArea.append(LYBSIS.catalogDisplay);
		displayArea.setEditable(false);
		getContentPane().add(memInfoPanel, BorderLayout.CENTER);
		memInfoPanel.setVisible(false); 
		getContentPane().add(addBookPanel, BorderLayout.CENTER); 
		addBookPanel.setVisible(false);
		getContentPane().add(scroll, BorderLayout.CENTER);
		scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		displayArea.setColumns(10);
		
		WestPanel westPanel = new WestPanel();
		getContentPane().add(westPanel, BorderLayout.WEST); 
		
		eastPanel.setPreferredSize(new Dimension(150, 100));
		eastPanel.setBackground(new Color(128, 222, 234));
		eastPanel.add(iconLabel); 
		getContentPane().add(eastPanel, BorderLayout.EAST); 

	}
}



