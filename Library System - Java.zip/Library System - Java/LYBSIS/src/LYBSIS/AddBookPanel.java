package LYBSIS;

import javax.swing.JPanel;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.GridBagConstraints;
import javax.swing.SwingConstants;
import javax.swing.JTextField;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.Checkbox;
import java.awt.Color;

public class AddBookPanel extends JPanel{
	public JTextField titleField;
	public JTextField authorField;
	public JTextField isbnField;
	public JTextField quantityField;
	public Checkbox borrowCheckBox = new Checkbox("Borrowable");
	public int bookIndex = -1; 
	public AddBookPanel() {
		setBackground(new Color(128, 222, 234));
		GridBagLayout gridBagLayout = new GridBagLayout();
		gridBagLayout.columnWidths = new int[]{0, 0};
		gridBagLayout.rowHeights = new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
		gridBagLayout.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gridBagLayout.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		setLayout(gridBagLayout);
		
		JLabel titleLabel = new JLabel("Title:");
		titleLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		GridBagConstraints gbc_titleLabel = new GridBagConstraints();
		gbc_titleLabel.insets = new Insets(0, 0, 5, 0);
		gbc_titleLabel.gridx = 0;
		gbc_titleLabel.gridy = 0;
		add(titleLabel, gbc_titleLabel);
		
		titleField = new JTextField();
		GridBagConstraints gbc_titleField = new GridBagConstraints();
		gbc_titleField.insets = new Insets(0, 0, 5, 0);
		gbc_titleField.fill = GridBagConstraints.HORIZONTAL;
		gbc_titleField.gridx = 0;
		gbc_titleField.gridy = 1;
		add(titleField, gbc_titleField);
		titleField.setColumns(10);
		
		JLabel authorLabel = new JLabel("Author:");
		GridBagConstraints gbc_authorLabel = new GridBagConstraints();
		gbc_authorLabel.insets = new Insets(0, 0, 5, 0);
		gbc_authorLabel.gridx = 0;
		gbc_authorLabel.gridy = 2;
		add(authorLabel, gbc_authorLabel);
		
		authorField = new JTextField();
		GridBagConstraints gbc_authorField = new GridBagConstraints();
		gbc_authorField.insets = new Insets(0, 0, 5, 0);
		gbc_authorField.fill = GridBagConstraints.HORIZONTAL;
		gbc_authorField.gridx = 0;
		gbc_authorField.gridy = 3;
		add(authorField, gbc_authorField);
		authorField.setColumns(10);
		
		JLabel isbnLabel = new JLabel("ISBN: ");
		GridBagConstraints gbc_isbnLabel = new GridBagConstraints();
		gbc_isbnLabel.insets = new Insets(0, 0, 5, 0);
		gbc_isbnLabel.gridx = 0;
		gbc_isbnLabel.gridy = 4;
		add(isbnLabel, gbc_isbnLabel);
		
		isbnField = new JTextField();
		GridBagConstraints gbc_isbnField = new GridBagConstraints();
		gbc_isbnField.insets = new Insets(0, 0, 5, 0);
		gbc_isbnField.fill = GridBagConstraints.HORIZONTAL;
		gbc_isbnField.gridx = 0;
		gbc_isbnField.gridy = 5;
		add(isbnField, gbc_isbnField);
		isbnField.setColumns(10);
		
		JLabel quantityLabel = new JLabel("Quantity:");
		GridBagConstraints gbc_quantityLabel = new GridBagConstraints();
		gbc_quantityLabel.insets = new Insets(0, 0, 5, 0);
		gbc_quantityLabel.gridx = 0;
		gbc_quantityLabel.gridy = 6;
		add(quantityLabel, gbc_quantityLabel);
		
		quantityField = new JTextField();
		GridBagConstraints gbc_quantityField = new GridBagConstraints();
		gbc_quantityField.insets = new Insets(0, 0, 5, 0);
		gbc_quantityField.fill = GridBagConstraints.HORIZONTAL;
		gbc_quantityField.gridx = 0;
		gbc_quantityField.gridy = 7;
		add(quantityField, gbc_quantityField);
		quantityField.setColumns(10);
		
		borrowCheckBox.setState(true);
		GridBagConstraints gbc_borrowCheckBox = new GridBagConstraints();
		gbc_borrowCheckBox.insets = new Insets(0, 0, 5, 0);
		gbc_borrowCheckBox.gridx = 0;
		gbc_borrowCheckBox.gridy = 8;
		add(borrowCheckBox, gbc_borrowCheckBox);
		
		JButton submitBtn = new JButton("Submit");
		GridBagConstraints gbc_submitBtn = new GridBagConstraints();
		gbc_submitBtn.gridx = 0;
		gbc_submitBtn.gridy = 9;
		add(submitBtn, gbc_submitBtn);
		submitBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else {
					try {
						int quantity = Integer.parseInt(quantityField.getText()); 
						//Book b = new Book(titleField.getText(), authorField.getText(), isbnField.getText(), quantity, borrowCheckBox.getState()); 
						if(bookIndex == -1) {
							Book b = new Book(titleField.getText(), authorField.getText(), isbnField.getText(), quantity, borrowCheckBox.getState());
							LYBSIS.catalog.add(b);
						}
						else {
							LYBSIS.catalog.get(bookIndex).setTitle(titleField.getText());
							LYBSIS.catalog.get(bookIndex).setAuthor(authorField.getText()); 
							LYBSIS.catalog.get(bookIndex).setIsbn(isbnField.getText());
							LYBSIS.catalog.get(bookIndex).setBorrowable(borrowCheckBox.getState());
						} 
						LYBSIS.appendOutputForTextArea(LYBSIS.catalog);
						LYBSIS.writeToFile();
						
						titleField.setText("");
						authorField.setText("");
						isbnField.setText("");
						quantityField.setText("");
						borrowCheckBox.setState(true); 
						bookIndex = -1; 
						
						LYBSIS.mainFrame.addBookPanel.setVisible(false);
						LYBSIS.mainFrame.scroll.setVisible(true); 
					}
					
					catch (Exception ex) {
						JOptionPane.showMessageDialog(null, "An Error has occured. You will need to retry your previous action", "Failure",  JOptionPane.ERROR_MESSAGE);
					}
				}
			}
		});
		
		JButton backBtn = new JButton("Go Back");
		GridBagConstraints gbc_backBtn = new GridBagConstraints();
		gbc_backBtn.gridx = 0;
		gbc_backBtn.gridy = 10;
		add(backBtn, gbc_backBtn);
		backBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				LYBSIS.mainFrame.addBookPanel.setVisible(false);
				LYBSIS.mainFrame.scroll.setVisible(true); 
				
				titleField.setText("");
				authorField.setText("");
				isbnField.setText("");
				quantityField.setText("");
				borrowCheckBox.setState(true);
			}
		});
	}
	
}
