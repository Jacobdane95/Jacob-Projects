package LYBSIS;

import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.FlowLayout;

public class LoginPanel extends JPanel{
	public static JTextField userIDField = new JTextField();
	public static JPasswordField passwordField = new JPasswordField();
	public LoginPanel() {
		setBackground(new Color(128, 222, 234));
		FlowLayout layout = new FlowLayout(FlowLayout.LEFT, 5, 5); 
		setLayout(layout);
		
		JLabel userIDLbl = new JLabel("UserID:");
		add(userIDLbl);
		
		add(userIDField);
		userIDField.setColumns(10);
		
		JLabel passwordLbl = new JLabel("Password:");
		add(passwordLbl);
		
		add(passwordField);
		passwordField.setColumns(10);
		
		//functionality of login button
		JButton loginBtn = new JButton("Login");
		add(loginBtn);
		loginBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e){
				String userID = userIDField.getText(); 
				userID.trim(); 
				String password = passwordField.getText(); 
				LYBSIS.setCurrentLibrarian(userID, password);
				
			}
		}); 
		
		JButton logoutBtn = new JButton("Logout");
		add(logoutBtn);
		logoutBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(LYBSIS.mainFrame, "You must be logged in to log out."); 
				}
				else {
					int input = JOptionPane.showConfirmDialog(LYBSIS.mainFrame, "Are you sure you want to log out?");
					if(input == JOptionPane.YES_OPTION) {
						LYBSIS.currentUser = LYBSIS.notLoggedIn; 
						LYBSIS.mainFrame.setTitle("LYBSIS");
						userIDField.setText("");
						passwordField.setText("");
					}
				}
				
			}
		});
		
	}
		
}
