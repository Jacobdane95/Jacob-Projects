package LYBSIS;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;

public class Member implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private String idNumber; 
	private String name; 
	private String email; 
	private String address; 
	private double fines; 
	private Calendar expirationDate; 
	private List<Book> booksBorrowed;
	
	public Member() {
		this.idNumber = "";
		this.name = "";
		this.email = "";
		this.address = ""; 
		this.fines = 0.0;
		this.expirationDate = null; 
		this.booksBorrowed = null; 
	}
	
	public Member(String idNumber, String name, String email, String address, Calendar expirationDate) {
		this.idNumber = idNumber; 
		this.name = name; 
		this.email = email; 
		this.address = address; 
		this.fines = 0.0; 
		this.expirationDate = expirationDate; 
		this.booksBorrowed = new ArrayList<>(); 
	}
	
	//set methods
	public void setName(String theName) {
		name = theName; 
	}
	
	public void setEmail(String theEmail) {
		email = theEmail; 
	}
	public void setAddress(String theAddress) {
		address = theAddress; 
	}
	public void setFines(double theFines) {
		fines = theFines; 
	}
	
	public void setExpirationDate(Calendar newExpirationDate) {
		expirationDate = newExpirationDate; 
	}
	
	public void setBooksBorrowed(List<Book> updatedList) {
		booksBorrowed = updatedList; 
	}
	
	//get methods
	public String getMemberID() {
		return idNumber; 
	}
	
	public String getName() {
		return name; 
	}
	
	public String getEmail() {
		return email; 
	}
	public String getAddress() {
		return address; 
	}
	public double getFines() {
		return fines; 
	}
	public List getBooksBorrowed() {
		return booksBorrowed; 
	}
	
	public void addToBooksBorrowed(Book book, Calendar returnDate) {
		booksBorrowed.add(0, book); 
		booksBorrowed.get(0).setReturnDate(returnDate);
	}
	
	public void removeFromBooksBorrowed(int index) {
		Calendar todayDate = Calendar.getInstance();  
		if(todayDate.after(booksBorrowed.get(index).getReturnDate())) {
			fines = fines + 5.0; 
		}
		booksBorrowed.remove(index); 
	}
	
	public Calendar getExpirationDate() {
		return  expirationDate; 
	}
	
	public String displayBooksBorrowed() {
		String memberList = "Member # " + idNumber + " has borrowed: \n"; 
		Date date; 
		Calendar calendar; 
		for(int i = 0; i < booksBorrowed.size(); i++) {
			int k = i + 1;
			calendar = booksBorrowed.get(i).getReturnDate(); 
			date = calendar.getTime(); 
			memberList = memberList + "Book " + k + ": " + booksBorrowed.get(i).getTitle() + " " 
									+ booksBorrowed.get(i).getAuthor() + " " 
									+ booksBorrowed.get(i).getIsbn() + " "
									+ booksBorrowed.get(i).getQuantity() + "\n"
									+ "Is due on: " + date;  
		}
		memberList += "\n"; 
		return memberList; 
	}
	
	//must be done by ISBN
	public int searchMemBooks(String entry) {
		boolean matchFound = false; 
		int index = -1; 
		for(int i = 0; i < booksBorrowed.size(); i++) {
			if(booksBorrowed.get(i).getIsbn().equalsIgnoreCase(entry)){
				index = i;
				matchFound = true; 
				break; 
			}
		}	
		
		if(!matchFound) {
			JOptionPane.showMessageDialog(null, "That ISBN number was not found in the member's list of books. "); 
		}
		return index; 
	}
	
	public boolean hasOverDueBook() {
		boolean overDueBook = false; 
		Calendar todayDate = Calendar.getInstance();  
		for(int i = 0; i < booksBorrowed.size(); i++) {
			if(todayDate.after(booksBorrowed.get(i).getReturnDate())) {
				overDueBook = true;  
			}
		}
		return overDueBook; 
	}
	
	//unfinished and unused function?
	public static Comparator<Member> BookNameComparator = new Comparator<Member>() {

		public int compare(Member m1, Member m2) {
		   String memID1 = m1.getMemberID().toUpperCase();
		   String memID2 = m2.getMemberID().toUpperCase();

		   //ascending order
		   return memID1.compareTo(memID2);
		}
	};
}
