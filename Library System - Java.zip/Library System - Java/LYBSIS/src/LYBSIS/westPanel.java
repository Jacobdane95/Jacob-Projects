package LYBSIS;

import javax.swing.JButton;
import javax.swing.JPanel;

import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Calendar;
import javax.swing.SwingConstants;

import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Color;

public class WestPanel extends JPanel{
	private JTextField searchField = new JTextField();
	private JTextField memIDField = new JTextField(); 
	public WestPanel() {
		setBackground(new Color(128, 222, 234));
		GridBagLayout gridBagLayout = new GridBagLayout();
		setLayout(gridBagLayout);
		
		JLabel searchLbl = new JLabel("<html>Search by title, <br>author, or ISBN");
		GridBagConstraints gbcSearchLbl = new GridBagConstraints();
		gbcSearchLbl.insets = new Insets(0, 0, 15, 0);
		gbcSearchLbl.anchor = GridBagConstraints.NORTHWEST;
		gbcSearchLbl.gridx = 0;
		gbcSearchLbl.gridy = 0;
		add(searchLbl, gbcSearchLbl);
		
		searchField.setHorizontalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcSearchField = new GridBagConstraints();
		gbcSearchField.insets = new Insets(0, 0, 15, 0);
		gbcSearchField.anchor = GridBagConstraints.NORTHWEST;
		gbcSearchField.gridx = 0;
		gbcSearchField.gridy = 1;
		gbcSearchField.fill = GridBagConstraints.HORIZONTAL;
		add(searchField, gbcSearchField);
		searchField.setColumns(10);
		
		JButton searchBtn = new JButton("Search");
		searchBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcSearchBtn = new GridBagConstraints();
		gbcSearchBtn.insets = new Insets(0, 0, 15, 0);
		gbcSearchBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcSearchBtn.gridx = 0;
		gbcSearchBtn.gridy = 2;
		gbcSearchBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(searchBtn, gbcSearchBtn);
		searchBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String input = searchField.getText(); 
				int bookIndex = LYBSIS.searchBook(input);
				JOptionPane.showMessageDialog(null, LYBSIS.catalog.get(bookIndex).displayInfo());
			}
		});
		
		JButton lendBtn = new JButton("Lend Book"); 
		lendBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcLendBtn = new GridBagConstraints(); 
		gbcLendBtn.insets = new Insets(0, 0, 15, 0);
		gbcLendBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcLendBtn.gridx = 0; 
		gbcLendBtn.gridy = 3; 
		gbcLendBtn.fill = GridBagConstraints.HORIZONTAL;
		add(lendBtn, gbcLendBtn); 
		
		//Lend Book 
		lendBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				
				else {
					String bookInput = searchField.getText(); 
					int bookIndex = LYBSIS.searchBook(bookInput);
					if(bookIndex == -1) {
						//error message handled by search function
					}
					else {
						String memID = memIDField.getText();
						int memIndex = LYBSIS.searchMember(memID); 
						if(memIndex == -1) {
							//error message handled by search function
						}
						
						else {
							LYBSIS.currentUser.lendBook(bookIndex, memIndex);
							LYBSIS.members.get(memIndex).displayBooksBorrowed(); 
							try {
								LYBSIS.writeToFile();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						
					}
					
				}
			}
		});
		
		JButton rtnBtn= new JButton("Return Book"); 
		rtnBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcRtnBtn = new GridBagConstraints();
		gbcRtnBtn.insets = new Insets(0, 0, 15, 0);
		gbcRtnBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcRtnBtn.gridx = 0;
		gbcRtnBtn.gridy = 4;
		gbcRtnBtn.fill = GridBagConstraints.HORIZONTAL;
		add(rtnBtn, gbcRtnBtn); 
		
		//Return Book
		rtnBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else{
					String memID = memIDField.getText();
					int memIndex = LYBSIS.searchMember(memID); 
					if(memIndex == -1) {
						//error message handled by search function
					}
						
					else {
						LYBSIS.currentUser.returnBook(memIndex);
						try {
							LYBSIS.writeToFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		
		JButton reserveBookBtn = new JButton("Reserve Book"); 
		reserveBookBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcReserveBookBtn = new GridBagConstraints();
		gbcReserveBookBtn.insets = new Insets(0, 0, 15, 0);
		gbcReserveBookBtn.anchor = GridBagConstraints.NORTHWEST; 
		gbcReserveBookBtn.gridx = 0; 
		gbcReserveBookBtn.gridy = 5; 
		gbcReserveBookBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(reserveBookBtn, gbcReserveBookBtn); 
		reserveBookBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else {
					String bookInput = searchField.getText(); 
					int bookIndex = LYBSIS.searchBook(bookInput);
					if(bookIndex == -1) {
						//error message handled by search function
					}
					else {
						String memID = memIDField.getText();
						int memIndex = LYBSIS.searchMember(memID); 
						if(memIndex == -1) {
							//error message handled by search function
						}
						
						else {
							LYBSIS.currentUser.reserveBook(bookIndex, memIndex);
							try {
								LYBSIS.writeToFile();
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
						
					}
					
				}
			}
		}); 
		
		JButton renewLoanBtn = new JButton("Renew Loan"); 
		renewLoanBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcRenewLoanBtn = new GridBagConstraints(); 
		gbcRenewLoanBtn.anchor = GridBagConstraints.NORTHWEST; 
		gbcRenewLoanBtn.insets = new Insets(0, 0, 15, 0);
		gbcRenewLoanBtn.gridx = 0;
		gbcRenewLoanBtn.gridy = 6; 
		gbcRenewLoanBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(renewLoanBtn, gbcRenewLoanBtn); 
		renewLoanBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else{
					String memID = memIDField.getText();
					int memIndex = LYBSIS.searchMember(memID); 
					if(memIndex == -1) {
						//error message handled by search function
					}
						
					else {
						LYBSIS.currentUser.renewLoan(memIndex); 
						try {
							LYBSIS.writeToFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				} 
			}
		});
		
		JButton payFinesBtn = new JButton("Pay Fines");
		payFinesBtn.setVerticalAlignment(SwingConstants.CENTER); 
		GridBagConstraints gbcPayFinesBtn = new GridBagConstraints();
		gbcPayFinesBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcPayFinesBtn.insets = new Insets(0, 0, 15, 0);
		gbcPayFinesBtn.gridx = 0;
		gbcPayFinesBtn.gridy = 7; 
		gbcPayFinesBtn.fill = GridBagConstraints.HORIZONTAL;
		add(payFinesBtn, gbcPayFinesBtn); 
		payFinesBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else{
					String memID = memIDField.getText();
					int memIndex = LYBSIS.searchMember(memID); 
					if(memIndex == -1) {
						//error message handled by search function
					}
						
					else {
						LYBSIS.currentUser.payFines(memIndex);
						try {
							LYBSIS.writeToFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
				} 
			}
		});
		
		JButton renewBtn = new JButton ("Renew Membership"); 
		renewBtn.setVerticalAlignment(SwingConstants.CENTER); 
		GridBagConstraints gbcRenewBtn = new GridBagConstraints(); 
		gbcRenewBtn.insets = new Insets(0, 0, 15, 0);
		gbcRenewBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcRenewBtn.gridx = 0; 
		gbcRenewBtn.gridy = 8;
		gbcRenewBtn.fill = GridBagConstraints.HORIZONTAL;
		add(renewBtn, gbcRenewBtn); 
		renewBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else {
					String memID = memIDField.getText(); 
					int memIndex = LYBSIS.searchMember(memID);
					if(memIndex == -1) {
						//error message handled by search function
					}
					
					else {
						Calendar expirationDate = LYBSIS.members.get(memIndex).getExpirationDate(); 
						expirationDate = LYBSIS.currentUser.renewMemberShip(LYBSIS.members.get(memIndex).getFines(), expirationDate, memIndex);
						LYBSIS.members.get(memIndex).setExpirationDate(expirationDate);
						try {
							LYBSIS.writeToFile();
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
					}
				}
			}
		});
		
		JLabel memIDLbl = new JLabel("Member ID#");
		memIDLbl.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcMemIDLbl = new GridBagConstraints();
		gbcMemIDLbl.insets = new Insets(0, 0, 15, 0);
		gbcMemIDLbl.anchor = GridBagConstraints.NORTHWEST; 
		gbcMemIDLbl.gridx = 0;
		gbcMemIDLbl.gridy = 9; 
		add(memIDLbl, gbcMemIDLbl); 
		
		
		GridBagConstraints gbcMemIDField = new GridBagConstraints(); 
		gbcMemIDField.anchor = GridBagConstraints.NORTHWEST; 
		gbcMemIDField.insets = new Insets(0, 0, 15, 0);
		gbcMemIDField.gridx = 0; 
		gbcMemIDField.gridy = 10; 
		gbcMemIDField.fill = GridBagConstraints.HORIZONTAL;
		add(memIDField, gbcMemIDField); 
		memIDField.setColumns(10); 
		
		JButton editMemBtn = new JButton("Edit Member Info"); 
		editMemBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcEditMemBtn = new GridBagConstraints(); 
		gbcEditMemBtn.insets = new Insets(0, 0, 15, 0); 
		gbcEditMemBtn.anchor = GridBagConstraints.NORTHWEST; 
		gbcEditMemBtn.gridx = 0; 
		gbcEditMemBtn.gridy = 11; 
		gbcEditMemBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(editMemBtn, gbcEditMemBtn); 
		editMemBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else {
					String memID = memIDField.getText(); 
					int memIndex = LYBSIS.searchMember(memID);
					if(memIndex == -1) {
						//error message handled by search function
					}
					else {
						LYBSIS.mainFrame.memInfoPanel.memIndex = memIndex; 
						LYBSIS.mainFrame.memInfoPanel.nameField.setText(LYBSIS.members.get(memIndex).getName());  
						LYBSIS.mainFrame.memInfoPanel.memIDField.setText(LYBSIS.members.get(memIndex).getMemberID());
						LYBSIS.mainFrame.memInfoPanel.emailField.setText(LYBSIS.members.get(memIndex).getEmail());
						LYBSIS.mainFrame.memInfoPanel.addressField.setText(LYBSIS.members.get(memIndex).getAddress());
						LYBSIS.mainFrame.memInfoPanel.memIDField.setEditable(false); 
						
						LYBSIS.mainFrame.scroll.setVisible(false);
						LYBSIS.mainFrame.getContentPane().add(LYBSIS.mainFrame.memInfoPanel, BorderLayout.CENTER); 
						LYBSIS.mainFrame.memInfoPanel.setVisible(true);
					}
				}
			}
		}); 
		
		JButton addMemBtn = new JButton("Add Member"); 
		addMemBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcAddMemBtn = new GridBagConstraints(); 
		gbcAddMemBtn.insets = new Insets(0, 0, 15, 0); 
		gbcAddMemBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcAddMemBtn.gridx = 0; 
		gbcAddMemBtn.gridy = 12; 
		gbcAddMemBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(addMemBtn, gbcAddMemBtn); 
		addMemBtn.addActionListener(new ActionListener() {
			
				public void actionPerformed(ActionEvent e) {
					if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
						JOptionPane.showMessageDialog(null, "A user must be logged in"); 
					}
					
					else {
						LYBSIS.mainFrame.memInfoPanel.memIDField.setEditable(true);
						LYBSIS.mainFrame.scroll.setVisible(false);
						LYBSIS.mainFrame.getContentPane().add(LYBSIS.mainFrame.memInfoPanel, BorderLayout.CENTER); 
						LYBSIS.mainFrame.memInfoPanel.setVisible(true);
					}
			}
		}); 
		
		JButton addBookBtn = new JButton("Add Book");
		addBookBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcAddBookBtn = new GridBagConstraints(); 
		gbcAddBookBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcAddBookBtn.insets = new Insets(0, 0, 15, 0);
		gbcAddBookBtn.gridx = 0; 
		gbcAddBookBtn.gridy = 13; 
		gbcAddBookBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(addBookBtn, gbcAddBookBtn); 
		addBookBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				else {
					LYBSIS.mainFrame.scroll.setVisible(false);
					LYBSIS.mainFrame.getContentPane().add(LYBSIS.mainFrame.addBookPanel, BorderLayout.CENTER); 
					LYBSIS.mainFrame.addBookPanel.setVisible(true);
				}
			}
		});
		
		JButton editBookBtn = new JButton("Edit Book");
		editBookBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcEditBookBtn = new GridBagConstraints(); 
		gbcEditBookBtn.anchor = GridBagConstraints.NORTHWEST;
		gbcEditBookBtn.insets = new Insets(0, 0, 15, 0);
		gbcEditBookBtn.gridx = 0; 
		gbcEditBookBtn.gridy = 14; 
		gbcEditBookBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(editBookBtn, gbcEditBookBtn); 
		editBookBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String input = searchField.getText(); 
				int bookIndex = LYBSIS.searchBook(input);
				
				if (LYBSIS.currentUser.equals(LYBSIS.notLoggedIn)) {
					JOptionPane.showMessageDialog(null, "A user must be logged in"); 
				}
				
				else if(bookIndex != -1){
					String quantity = String.valueOf(LYBSIS.catalog.get(bookIndex).getQuantity()); 
					
					LYBSIS.mainFrame.addBookPanel.bookIndex = bookIndex; 
					LYBSIS.mainFrame.addBookPanel.titleField.setText(LYBSIS.catalog.get(bookIndex).getTitle());
					LYBSIS.mainFrame.addBookPanel.authorField.setText(LYBSIS.catalog.get(bookIndex).getAuthor()); 
					LYBSIS.mainFrame.addBookPanel.isbnField.setText(LYBSIS.catalog.get(bookIndex).getIsbn());
					LYBSIS.mainFrame.addBookPanel.quantityField.setText(quantity); 
					LYBSIS.mainFrame.addBookPanel.borrowCheckBox.setState(LYBSIS.catalog.get(bookIndex).getBorrowable());
					
					LYBSIS.mainFrame.scroll.setVisible(false);
					LYBSIS.mainFrame.getContentPane().add(LYBSIS.mainFrame.addBookPanel, BorderLayout.CENTER); 
					LYBSIS.mainFrame.addBookPanel.setVisible(true);
				}
			}
		});
		
		
		//mainly used for debugging
		JButton showMembersBtn = new JButton("Show Members"); 
		showMembersBtn.setVerticalAlignment(SwingConstants.CENTER);
		GridBagConstraints gbcShowMembersBtn = new GridBagConstraints();
		gbcShowMembersBtn.insets = new Insets(0, 0, 15, 0);
		gbcShowMembersBtn.anchor = GridBagConstraints.NORTHWEST; 
		gbcShowMembersBtn.gridx = 0; 
		gbcShowMembersBtn.gridy = 15; 
		gbcShowMembersBtn.fill = GridBagConstraints.HORIZONTAL; 
		add(showMembersBtn, gbcShowMembersBtn); 
		showMembersBtn.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				String output = ""; 
				for(int i = 0; i < LYBSIS.members.size(); i++) {
					output += LYBSIS.members.get(i).displayBooksBorrowed()
							+ "\n Owes: " + LYBSIS.members.get(i).getFines() + "\n"; 
				}
				
				JOptionPane.showMessageDialog(null, output); 
			}
		});
		
	}
	
}
