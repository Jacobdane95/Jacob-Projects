package LYBSIS;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;

public class LYBSIS {
	static final Librarian notLoggedIn = new Librarian("", "", ""); 
	static Librarian currentUser = notLoggedIn;
	static List<Librarian> librarians = new ArrayList<>(); 
	static List<Member> members = new ArrayList<>(); 
	static List<Book> catalog = new ArrayList<>(); 
	static String catalogDisplay = ""; 
	static int borrowBookDuration = 21; //days
	static MainFrame mainFrame = new MainFrame(); 
	static List<Book> reservedBooks = new ArrayList<>(); 
	static String catalogFilePath = "D:\\Java Apps\\LYBSIS\\catalog"; 
	static String membersFilePath = "D:\\Java Apps\\LYBSIS\\members"; 
	
	public static String title = "LYBSIS"; 

	public static void main(String[] args) throws IOException { 
		catalog = addTestBooks(); 
		members = addMembers();
		readFromFile(); 
		//checkForDoubles(); 
		librarians = addLibrarians();  
		appendOutputForTextArea(catalog); 
		mainFrame.displayArea.append(catalogDisplay);
		mainFrame.setVisible(true); 
		writeToFile(); 
	}
	
	//Test adding books
	public static List<Book> addTestBooks() {
		List<Book> theBooks = new ArrayList<>(); 
		Book a = new Book("Dracula" , "Bram Stocker", "9375144", 2, true); 
		Book b = new Book("Intro to Java Programming", "Daniel Liang", "9569420", 1, false);
		Book c = new Book("Roughing It", "Mark Twain", "7451299", 3, true); 
		Book d = new Book("Resident Evil: City of the Dead", "S.D. Perry", "7658901", 2, true); 
		Book e = new Book("The Hobbit", "J.R.R. Tolkien", "4205671", 1, true);
		Book f = new Book("Battle Royale", "Koushun Takami", "1049832", 1, true);
		Book g = new Book("Fight Club", "Chuck Palahniuk", "7652135", 2, true); 
		
		theBooks.add(a);
		theBooks.add(b);
		theBooks.add(c);
		theBooks.add(d); 
		theBooks.add(e); 
		theBooks.add(f); 
		theBooks.add(g); 
		
		return theBooks; 
	}

	//Test adding librarians
	public static List<Librarian> addLibrarians(){
		List<Librarian> theLibrarians = new ArrayList<>(); 
		Librarian a = new Librarian("Jacob Johnson", "496422" , "drake01"); 
		Librarian b = new Librarian("John Doe", "288609", "terra18"); 
		
		theLibrarians.add(a); 
		theLibrarians.add(b); 
		return theLibrarians; 
	}
	
	//Test adding members 
	public static List<Member> addMembers(){
		List<Member> theMembers = new ArrayList<>(); 
		Calendar expirationDate = Calendar.getInstance(); 
		Calendar expiredMembership = Calendar.getInstance(); 
		expiredMembership.add(Calendar.YEAR, -1); 
		expirationDate.add(Calendar.YEAR, 3);
		Member a = new Member("123456", "Leon Kennedy", "lsk1993@gmail.com", "1234 Main St", expirationDate); 
		Member b = new Member("252719", "Joel Miller", "joelmill89@hotmail.com", "9375 Liberty Dr",  expirationDate); 
		Member c = new Member("098765", "Josh Maitra", "thejoshfather@yahoo.com", "4570 Cody Rd", expiredMembership);
		c.setFines(25.0);
		
		theMembers.add(a); 
		theMembers.add(b); 
		theMembers.add(c); 
		return theMembers;  
	}
	
	//search for book by title, author, or ISBN
	public static int searchBook(String entry) {
		int index = -1; 
		//List<Integer> indexList = new ArrayList<>(); think of how to return multiple indexes for mult authors, etc.
		boolean matchFound = false; 
		for(int i = 0; i < catalog.size(); i++) {
			if(catalog.get(i).getTitle().equalsIgnoreCase(entry)){
				index = i; 
				matchFound = true; 
				break;
			}
		}
		
		for(int i = 0; i < catalog.size(); i++) {
			if(catalog.get(i).getIsbn().equalsIgnoreCase(entry)){
				index = i; 
				matchFound = true; 
				break;
			}
		}
		
		for(int i = 0; i < catalog.size(); i++) {
			if(catalog.get(i).getTitle().equalsIgnoreCase(entry)){
				index = i; 
				matchFound = true; 
				break; 
			}
		}
		
		if(!matchFound) {
			JOptionPane.showMessageDialog(mainFrame,"No book was found using keyword: " + entry);
		}
		
		return index; 
		/*if (catalog.stream().anyMatch(t -> t.getTitle().equalsIgnoreCase(entry))) {
			  JOptionPane.showMessageDialog(null, "Found"); 
		}
		
		else if (catalog.stream().anyMatch(a -> a.getAuthor().equalsIgnoreCase(entry))) {
			JOptionPane.showMessageDialog(null, "Found");
		}
		
		else if (catalog.stream().anyMatch(a -> a.getIsbn().equalsIgnoreCase(entry))) {
			JOptionPane.showMessageDialog(null, "Found");
		}
		
		else {
			JOptionPane.showMessageDialog(null, "Not Found");
		}	*/
	}
	
	public static int searchMember(String entry) {
		int index = -1; 
		boolean matchFound = false; 
		for(int i=0; i < members.size(); i++) {
			if(members.get(i).getMemberID().equals(entry)) {
				index = i; 
				matchFound = true; 
				break; 
			}
		}
		
		if(!matchFound) {
			JOptionPane.showMessageDialog(null, "There is no record of member with ID: " + entry);
		}
		
		return index; 
	}
	
	public static void setCurrentLibrarian(String userID, String password) {
		boolean matchFound = false; 
		for(int i=0; i < librarians.size(); i++) {
			if((librarians.get(i).getUserID().equals(userID)) && (librarians.get(i).getPassword().equals(password))) {
				currentUser = librarians.get(i); 
				matchFound = true; 
				JOptionPane.showMessageDialog(null, "Hello " + currentUser.getName()); 
				mainFrame.setTitle(currentUser.getName());
				LoginPanel.userIDField.setText("");
				LoginPanel.passwordField.setText("");
				break; 
			}
		}
		
		if(!matchFound) {
			JOptionPane.showMessageDialog(null, "UserID or Password is incorrect. "); 
		}
	}
	
	public static void appendOutputForTextArea(List<Book> catalog) {
		Collections.sort(catalog, Book.BookNameComparator);
		String output = "Title: \tAuthor: \tISBN: \tQuantity: \tBorrowable: \n"; 
		mainFrame.displayArea.setText("");
		for(int i = 0; i<catalog.size(); i++) {
			String title = catalog.get(i).getTitle(); 
			if (title.length() > 27) {
				title = title.substring(0, 24); 
				title += "..."; 
			}
			output += title + "\t"
					+ catalog.get(i).getAuthor() + "\t"
					+ catalog.get(i).getIsbn() + "\t"
					+ catalog.get(i).getQuantity() + "\t" 
					+ catalog.get(i).getBorrowable() + "\n";
		}
		
		mainFrame.displayArea.setText(output);		
	}
	
	public static void writeToFile() throws IOException { 
		
		try {
			FileOutputStream fileOutCatalog = new FileOutputStream(catalogFilePath); 
			ObjectOutputStream catalogOut = new ObjectOutputStream(fileOutCatalog); 
			catalogOut.writeObject(catalog);
			catalogOut.close(); 
			
			FileOutputStream fileOutMembers = new FileOutputStream(membersFilePath); 
			ObjectOutputStream membersOut = new ObjectOutputStream(fileOutMembers); 
			membersOut.writeObject(members);
			membersOut.close(); 
		}
		
		catch(Exception e) {
			JOptionPane.showMessageDialog(null, "File Output Error. Check File Paths in LYBSIS.", "Failure",  JOptionPane.ERROR_MESSAGE); 
		}
	}
	
	@SuppressWarnings("unchecked")
	public static void readFromFile() throws IOException {
		
		try {
			FileInputStream fileInCatalog = new FileInputStream(catalogFilePath); 
			@SuppressWarnings("resource")
			ObjectInputStream catalogIn = new ObjectInputStream(fileInCatalog); 
			catalog = (List<Book>) catalogIn.readObject();
			
			FileInputStream fileInMembers = new FileInputStream(membersFilePath); 
			@SuppressWarnings("resource")
			ObjectInputStream membersIn = new ObjectInputStream(fileInMembers); 
			members = (List<Member>) membersIn.readObject(); 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "File Input Error. Loading Hard-Coded Catalog and Members.","File I/O Failure",  
					JOptionPane.ERROR_MESSAGE );
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "File Input Error. Loading Hard-Coded Catalog and Members", "File I/O Failure",
					JOptionPane.ERROR_MESSAGE);
		} 
	}
	
	public static void checkForDoubles() {
		for(int i = 0; i <catalog.size(); i++) {
			if(catalog.get(i).equals(catalog.get(i+1))) {
				catalog.remove(i+1); 
				break; 
			}
		}
	}
}












