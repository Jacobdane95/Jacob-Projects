var bgImages = ["hayabusaRider.jpg", "girlOnBike.jpg", "groupRide.jpg",  "sunsetRider.jpg"];
var secs = 4; 
let selectedYear; 
let selectedMake; 
let selectedModel; 
let part; 
let searchResult; 
//to ease the transitioning of images
bgImages.forEach(function(img){
    new Image().src = img; 
}); 

//causes the background to fade between different images
function backgroundSequence(){
    window.clearTimeout(); 
    var k = 0; 

    for(i = 0; i < bgImages.length; i++){
        setTimeout(function(){
            document.documentElement.style.background =
            "url(" + bgImages[k] + ") no-repeat center center fixed"; 

            document.documentElement.style.backgroundSize = "cover";
            if((k + 1) === bgImages.length){
                setTimeout(function() {backgroundSequence()}, (secs * 1000))
            }
            else{
                k++; 
            }
        }, (secs * 1000) * i)
    }
}
backgroundSequence(); 

function getYear(){
    var selectedYear = document.getElementById("year").value; 
    return selectedYear; 
}

function getMake(){
    var selectedMake = document.getElementById("make").value; 
    return selectedMake; 
}

function getModel(){
    var selectedModel = document.getElementById("model").value; 
    return selectedModel; 
}

function getPart(){
    var part = document.getElementById("part"); 
    return part; 
}

function storeSearchQuery(){
    searchResult = "Showing results for: " + getYear() + " " + getMake() + " " + getModel() + " " + getPart(); 
    localStorage.setItem("objectToPass", searchResult); 
}

function search(){
    getYear();
    getMake();
    getModel();
    getPart();  
    //addToHome(); 
    //storeSearchQuery(); 
    window.open("Market Launch.html", "_self"); 
}


function setYears(){
    var current = new Date().getFullYear();
    var end =  1970; 
    var options = "";
    for(var year = current; year >= end; year--){
        options += "<option>" + year + "</option>"; 
    }

    return options; 
}

function setModels(){
    make = document.getElementById("make").value;                     
    const hondaModels = ["CB500","CBR600", "VTX1300"];
    const suzukiModels = ["GSXR600", "GSX1300R Hayabusa"]; 

    let models = ""; 
    if(make == "Honda"){
        for(let x of hondaModels){
            models += "<option>" + x + "</option>";
        }
    }

    else if(make == "Suzuki"){
        for(let x of suzukiModels){
            models += "<option>" + x + "</option>"; 
        }
    }

    document.getElementById("model") = models; 
}

function addToHome(){
    searchResult = "Showing results for: " + getYear() + " " + getMake() + " " + getModel() + " " + getPart(); 
    document.getElementById("test").innerHTML = searchResult; 
}